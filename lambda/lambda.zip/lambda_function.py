import json
import boto3
import pickle

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('tb_case_software_engineer')

with open('model2.pkl', 'rb') as f:
    model = pickle.load(f)

def create(body):
    features = body.get('features', [])
    passenger_id = body.get('passenger_id')

    probability = model.predict_proba([features])[0][1]

    table.put_item(Item={
        'passenger_id': passenger_id,
        'probability': str(probability)
    })

    return {
        'statusCode': 200,
        'body': json.dumps({
            'passenger_id': passenger_id,
            'probability': probability
        })
    }

def list():
    response = table.scan()
    items = response.get('Items', [])

    return {
        'statusCode': 200,
        'body': json.dumps(items)
    }

def get(passenger_id):
    response = table.get_item(Key={'passenger_id': passenger_id})
    item = response.get('Item')
    if item:
        return {'statusCode': 200, 'body': json.dumps(item)}
    else:
        return {'statusCode': 404, 'body': json.dumps({'error': 'Not found'})}
    
def delete(passenger_id):
    table.delete_item(Key={'passenger_id': passenger_id})
    return {
        'statusCode': 200, 
        'body': json.dumps({
            'message': f'Passageiro {passenger_id} deletado com sucesso'
        })
    }

def lambda_handler(event, context):
    print("EVENT RECEBIDO:", event)
    http_method = event['requestContext']['http']['method']
    path = event['rawPath']
    
    try:
        if http_method == 'POST':
            body = json.loads(event['body']) if isinstance(event.get('body'), str) else event.get('body')
            return create(body)

        elif http_method == 'GET' and path == '/sobreviventes':
            return list()

        elif http_method == 'GET' and path.startswith('/sobreviventes/'):
            passenger_id = event.get('pathParameters', {}).get('id')
            if not passenger_id:
                return {'statusCode': 400, 'body': json.dumps({'error': 'passenger_id é um parametro obrigatório'})}
            return get(passenger_id)

        elif http_method == 'DELETE':
            passenger_id = event.get('pathParameters', {}).get('id')
            if not passenger_id:
                return {'statusCode': 400, 'body': json.dumps({'error': 'passenger_id é um parametro obrigatório'})}
            return delete(passenger_id)

        else:
            return {
                'statusCode': 405,
                'body': json.dumps({'error': 'Método Inválido'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
